import 'package:flutter/material.dart';
class InstitutionAddition extends StatefulWidget {
  const InstitutionAddition({Key? key}) : super(key: key);

  @override
  _InstitutionAdditionState createState() => _InstitutionAdditionState();
}

class _InstitutionAdditionState extends State<InstitutionAddition> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
