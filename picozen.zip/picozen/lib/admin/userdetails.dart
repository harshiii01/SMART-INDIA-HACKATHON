import 'package:flutter/material.dart';
class RemoveInstitue extends StatefulWidget {
  const RemoveInstitue({Key? key}) : super(key: key);

  @override
  _RemoveInstitueState createState() => _RemoveInstitueState();
}

class _RemoveInstitueState extends State<RemoveInstitue> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
