import 'package:flutter/material.dart';
class InstitutionProfile extends StatefulWidget {
  const InstitutionProfile({Key? key}) : super(key: key);

  @override
  _InstitutionProfileState createState() => _InstitutionProfileState();
}

class _InstitutionProfileState extends State<InstitutionProfile> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
