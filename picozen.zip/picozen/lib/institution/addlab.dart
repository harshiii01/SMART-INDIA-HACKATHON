import 'package:flutter/material.dart';
class AddLab extends StatefulWidget {
  const AddLab({Key? key}) : super(key: key);

  @override
  _AddLabState createState() => _AddLabState();
}

class _AddLabState extends State<AddLab> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
