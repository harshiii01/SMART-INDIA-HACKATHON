import 'package:flutter/material.dart';
class StudentStatusTab extends StatefulWidget {
  const StudentStatusTab({Key? key}) : super(key: key);

  @override
  _StudentStatusTabState createState() => _StudentStatusTabState();
}

class _StudentStatusTabState extends State<StudentStatusTab> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
